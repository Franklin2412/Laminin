# android-socket.io-client-demo
client side java code for android socket.o-demo
